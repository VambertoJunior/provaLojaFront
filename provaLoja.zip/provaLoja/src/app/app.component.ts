import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import {Produto} from "./shared/modelo/produto";
import {ProdutoService} from "./shared/service/produto-service.service";
import {LojaModule} from "./loja/loja.module";

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, LojaModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})

export class AppComponent {
  title = 'provaLoja';
  produto: Produto;

  constructor() {
    this.produto = new Produto(0, '','', 0,[])
  }
}
