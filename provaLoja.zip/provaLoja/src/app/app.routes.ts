import { Routes } from '@angular/router';
import {ListagemProdutosComponent} from "./loja/listagem-produtos/listagem-produtos.component";
import {DetalhesProdutosComponent} from "./loja/detalhes-produtos/detalhes-produtos.component";


export const routes: Routes = [
  {
    path: "listagem-produto",
    component: ListagemProdutosComponent,
  },
  {
    path: "detalhes-produto/:id",
    component: DetalhesProdutosComponent,
  },
];

