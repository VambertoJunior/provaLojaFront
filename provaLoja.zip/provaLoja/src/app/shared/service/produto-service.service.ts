import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Produto } from '../modelo/produto';
import { Imagem } from '../modelo/imagem';

@Injectable({
  providedIn: 'root',
})
export class ProdutoService {
  private apiUrl = "http://localhost:8080/produto";

  constructor(private http: HttpClient) {}

  getProdutos(): Observable<Produto[]> {
    return this.http.get<Produto[]>(this.apiUrl);
  }

  adicionarProduto(novoProduto: Produto): Observable<void> {
    return this.http.post<void>(this.apiUrl, novoProduto);
  }

  editarProduto(produtoEditado: Produto): Observable<void> {
    const url = `${this.apiUrl}/${produtoEditado.id}`;
    return this.http.put<void>(url, produtoEditado);
  }

  excluirProduto(id: number): Observable<void> {
    const url = `${this.apiUrl}/${id}`;
    return this.http.delete<void>(url);
  }

  getDetalhesProduto(id: number): Observable<Produto> {
    const url = `${this.apiUrl}/produtos/${id}`;
    return this.http.get<Produto>(url);
  }

  adicionarImagemAoProduto(produtoId: number, imagem: Imagem): Observable<void> {
    const url = `${this.apiUrl}/produtos/${produtoId}/imagens`;
    return this.http.post<void>(url, imagem);
  }

  editarDetalhesImagem(imagemId: number, imagem: Imagem): Observable<void> {
    const url = `${this.apiUrl}/imagens/${imagemId}`;
    return this.http.put<void>(url, imagem);
  }

  excluirImagemDoProduto(produtoId: number, imagemId: number): Observable<void> {
    const url = `${this.apiUrl}/produtos/${produtoId}/imagens/${imagemId}`;
    return this.http.delete<void>(url);
  }
}
