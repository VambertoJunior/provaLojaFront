import { Produto } from './produto';

export class Imagem {
  id: number;
  nome: string;
  url: string;
  produto: Produto | null;

  constructor(id: number, nome: string, url: string, produto: Produto) {
    this.id = id;
    this.nome = nome;
    this.url = url;
    this.produto = produto;
  }
}
