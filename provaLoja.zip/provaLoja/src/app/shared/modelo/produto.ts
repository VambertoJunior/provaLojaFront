import {Imagem} from "./imagem";

export class Produto {
  id: number;
  nome: string;
  descricao: string;
  preco: number;
  imagens: Imagem[];

  constructor(id: number, nome: string, descricao: string, preco: number, imagens: Imagem[]) {
    this.id = id;
    this.nome = nome;
    this.descricao = descricao;
    this.preco = preco;
    this.imagens = imagens;
  }
}
