import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {ListagemProdutosComponent} from "./loja/listagem-produtos/listagem-produtos.component";
import {DetalhesProdutosComponent} from "./loja/detalhes-produtos/detalhes-produtos.component";

const routes: Routes = [
  {
    path: "listagem-produto",
    component: ListagemProdutosComponent,
  },
 {
    path: "detalhes-produto/:id",
    component: DetalhesProdutosComponent,
  },
];
@NgModule({
  imports: [RouterModule.forRoot(routes, { enableTracing: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
