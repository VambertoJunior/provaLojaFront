import { Component } from '@angular/core';

@Component({
  selector: 'app-edicao-imagem',
  standalone: true,
  imports: [],
  templateUrl: './edicao-imagem.component.html',
  styleUrl: './edicao-imagem.component.css'
})
export class EdicaoImagemComponent {

}
