import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {ListagemProdutosComponent} from "./listagem-produtos/listagem-produtos.component";
import {DetalhesProdutosComponent} from "./detalhes-produtos/detalhes-produtos.component";
import {ProdutoService} from "../shared/service/produto-service.service";
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import {MatCardModule} from "@angular/material/card";
import {HttpClientModule} from "@angular/common/http";



@NgModule({
  declarations: [
    ListagemProdutosComponent,
    DetalhesProdutosComponent,
  ],
  exports: [
    ListagemProdutosComponent
  ],
  imports: [
    CommonModule,
    MatButtonModule,
    MatIconModule,
    MatCardModule,
    HttpClientModule
  ],
  providers: [
    ProdutoService
  ]
})
export class LojaModule { }
